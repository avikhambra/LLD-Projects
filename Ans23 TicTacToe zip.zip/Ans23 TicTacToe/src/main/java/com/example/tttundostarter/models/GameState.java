package com.example.tttundostarter.models;

public enum GameState {
    IN_PROGRESS,
    ENDED,
    DRAW,
}

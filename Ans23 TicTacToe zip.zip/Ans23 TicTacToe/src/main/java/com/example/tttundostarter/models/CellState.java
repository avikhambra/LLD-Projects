package com.example.tttundostarter.models;

public enum CellState {
    EMPTY,
    FILLED,
}

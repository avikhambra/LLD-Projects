package com.example.tttundostarter.models;

public class Bot {
}
